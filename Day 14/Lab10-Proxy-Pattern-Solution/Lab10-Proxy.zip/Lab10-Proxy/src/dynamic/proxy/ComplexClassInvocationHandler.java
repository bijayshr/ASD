package dynamic.proxy;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class ComplexClassInvocationHandler implements InvocationHandler {
    ComplexClass complexClass;

    public ComplexClassInvocationHandler(ComplexClass complexClass){
        this.complexClass = complexClass;
    }
    @Override
    public Object invoke(Object proxy, Method method, Object[] args) throws IllegalAccessException {
        try{
            if(method.getName().startsWith("very")){
                return method.invoke(complexClass, args);
            }
        }catch(InvocationTargetException e) {
            e.printStackTrace();
        }
        return null;
    }
}
