package dynamic.proxy;

public interface ComplexClass {
    void veryComplicatedTask() throws InterruptedException;
}
