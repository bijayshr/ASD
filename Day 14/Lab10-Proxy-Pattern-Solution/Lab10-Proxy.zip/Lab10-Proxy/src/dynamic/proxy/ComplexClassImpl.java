package dynamic.proxy;

public class ComplexClassImpl implements ComplexClass{

    public ComplexClassImpl()throws InterruptedException{
        super();
        Thread.sleep(10000);
    }

    @Override
    public void veryComplicatedTask() {
        System.out.println("Very Complicated task ...");
    }
}
