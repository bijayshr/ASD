package dynamic.proxy;

import java.lang.reflect.Proxy;

public class ComplexClassTestDrive {
    public static void main(String[] args) throws InterruptedException {
        ComplexClassTestDrive test = new ComplexClassTestDrive();
        //DYNAMIC PROXY
        System.out.println("Initiating ... ");
        ComplexClass testClass = new ComplexClassImpl();
        ComplexClass complexClass = test.getComplexClassProxy(testClass);
        complexClass.veryComplicatedTask();

        System.out.println("Second call ..");
        complexClass.veryComplicatedTask();

    }

    ComplexClass getComplexClassProxy(ComplexClass complexClass){
        return (ComplexClass) Proxy.newProxyInstance(
                complexClass.getClass().getClassLoader(),
                complexClass.getClass().getInterfaces(),
                new ComplexClassInvocationHandler(complexClass)
        );
    }
}
