package virtual.proxy;

import dynamic.proxy.ComplexClass;

public class ComplexClassVirtualProxyTestDriver {
    public static void main(String[] args) throws Exception{
        ComplexClassVirtualProxyTestDriver test = new ComplexClassVirtualProxyTestDriver();
    }
    public ComplexClassVirtualProxyTestDriver() throws Exception{
        ComplexClass complexClass = new ComplexClassVirtualProxy();
        complexClass.veryComplicatedTask();
    }
}
