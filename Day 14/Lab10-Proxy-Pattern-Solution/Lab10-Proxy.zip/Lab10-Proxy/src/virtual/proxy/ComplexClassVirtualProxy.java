package virtual.proxy;

import dynamic.proxy.ComplexClass;
import dynamic.proxy.ComplexClassImpl;

public class ComplexClassVirtualProxy implements ComplexClass {
    volatile ComplexClassImpl complexClassImpl;

    public void veryComplicatedTask() throws InterruptedException {
        if (complexClassImpl == null) {
            System.out.println("Loading .... ");
            setComplexClassImpl(new ComplexClassImpl());
        }
        complexClassImpl.veryComplicatedTask();
    }

    synchronized void setComplexClassImpl(ComplexClassImpl complexClassImpl){
        this.complexClassImpl = complexClassImpl;
    }

}
