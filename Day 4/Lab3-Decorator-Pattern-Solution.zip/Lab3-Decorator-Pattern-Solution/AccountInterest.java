package lab3;

public interface AccountInterest {
    double addInterest(double balance);
}
