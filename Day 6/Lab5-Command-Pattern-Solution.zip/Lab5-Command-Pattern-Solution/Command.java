package lab5;

public interface Command {
     void undo();
}
