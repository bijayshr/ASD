package lab7;

import java.util.function.Consumer;

public abstract class Hire {
    abstract Integer count();
    abstract Double computeTotalSalary();
    abstract void accept(Consumer<Hire> action);
    abstract Double getSalary();
}
