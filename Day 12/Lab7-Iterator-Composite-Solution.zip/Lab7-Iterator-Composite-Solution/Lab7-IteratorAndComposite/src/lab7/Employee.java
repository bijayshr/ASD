package lab7;

import java.util.function.Consumer;

public class Employee extends Hire {

    private Integer id;
    private String name;
    private String emailAddress;
    private Double salary;

    public Employee(Integer id, String name, String emailAddress, Double salary){
        super();
        this.id = id;
        this.name = name;
        this.emailAddress = emailAddress;
        this.salary = salary;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public Double getSalary() {
        return salary;
    }

    public void setSalary(Double salary) {
        this.salary = salary;
    }

    @Override
    public Integer count(){
        return 1;
    }

    @Override
    public Double computeTotalSalary(){
        return getSalary();
    }

    @Override
    public void accept(Consumer<Hire> action) {
        action.accept(this);
    }

}
