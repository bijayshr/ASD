package lab7;

public class Client {
    public static void main(String[] args) {
        Hire samHarris = new Employee(1, "Sam Harris", "joerogan@miu.edu", 2D);
        Hire kristaTrippet = new Employee(2, "Krista Trippet", "kristatrippet@miu.edu", 1D);
        Hire sethGodin = new Employee(3, "Seth Godin", "sethgodin@miu.edu", 1D);
        Hire simonSinek = new Employee(4, "Simon Sinek", "simonsinek@miu.edu", 2D);

        Manager ceo = new Manager(simonSinek, 3D);
        ceo.addHire(samHarris);
        ceo.addHire(sethGodin);
        ceo.addHire(kristaTrippet);

        System.out.println();
        System.out.println("----------------Total Salary Computation without consumer --------------------");
        Double totalSalary = ceo.computeTotalSalary();
        System.out.println("Total Salary (Without Consumer) :: " + totalSalary);
        HireCounterConsumer consumerObj = new HireCounterConsumer();
        System.out.println("--------------------------------------------------");
        System.out.println();

        System.out.println("--------------- Hire Counter Computation ----------------------");
        ceo.accept(consumerObj);
        System.out.println("Hire Counter Output :: " + consumerObj.getCount());
        System.out.println("--------------------------------------------------");
        System.out.println();


        System.out.println("--------------- Hire Salary Consumer Computation ----------------------");
        HireSalaryConsumer hireSalaryConsumer = new HireSalaryConsumer();
        ceo.accept(hireSalaryConsumer);
        System.out.println("Total Salary Output (With Consumer) :: " + hireSalaryConsumer.getSalary());
        System.out.println("--------------------------------------------------");
        System.out.println();

    }
}
