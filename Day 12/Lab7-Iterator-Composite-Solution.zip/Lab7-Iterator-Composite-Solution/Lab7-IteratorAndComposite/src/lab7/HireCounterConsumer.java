package lab7;

import java.util.function.Consumer;

public class HireCounterConsumer implements Consumer<Hire> {
    private Integer count = 0;
    @Override
    public void accept(Hire hire) {
        count++;
    }

    public Integer getCount(){
        return count;
    }
}
