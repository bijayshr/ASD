package lab7;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

public class Manager extends Hire {
    private Double bonus;
    private Hire hire;
    private List<Hire> hires = new ArrayList<Hire>();

    public Manager(Hire hire, Double bonus){
        super();
        this.hire = hire;
        this.bonus = bonus;
    }

    public void addHire(Hire hire){
        hires.add(hire);
    }

    public Double getBonus(){
        return bonus;
    }

    public Hire getHire(){
        return hire;
    }

    public void setBonus(Double bonus) {
        this.bonus = bonus;
    }

    public void setHire(Hire hire) {
        this.hire = hire;
    }

    @Override
    public Integer count() {
        Integer count = 1;
        for (Hire hire : hires) {
            count += hire.count();
        }
        return count;
    }

    @Override
    public Double computeTotalSalary() {
        Double salaryOfManager = getHire().getSalary() + this.bonus;
        for (Hire hire : hires) {
            salaryOfManager += hire.getSalary();
        }
        return salaryOfManager;
    }

    @Override
    public void accept(Consumer<Hire> action) {
        action.accept(this);
        for(Hire h: hires){
            h.accept(action);
        }
    }

    @Override
    Double getSalary() {
        return hire.getSalary() + this.bonus;
    }

//    @Override
//    public void accept(Consumer<? extends Hire> action) {
//        super.accept(action);
//        for(Hire hire: hires){
//            employee.accept(action);
//        }
//    }


}
