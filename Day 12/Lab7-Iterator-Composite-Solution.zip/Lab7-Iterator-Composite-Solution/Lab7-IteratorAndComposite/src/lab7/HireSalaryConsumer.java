package lab7;

import java.util.function.Consumer;

public class HireSalaryConsumer implements Consumer<Hire> {
    private Double salary = 0D;

    @Override
    public void accept(Hire hire) {
        salary += hire.getSalary();
    }

    public Double getSalary(){
        return salary;
    }
}
