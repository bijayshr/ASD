package lab6;

public class Main {

    public static void main(String[] args) {
        Logger adapter = new LoggerAdapter();
        adapter.log(LogLevel.TRACE, "LoggerAdapter Message");
    }
}
