package lab6;

public enum LogLevel {
    DEBUG, ERROR, FATAL, INFO, TRACE, WARNING
}
