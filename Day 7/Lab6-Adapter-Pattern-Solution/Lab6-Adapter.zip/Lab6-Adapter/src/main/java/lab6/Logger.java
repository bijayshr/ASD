package lab6;

public interface Logger {
    void log(LogLevel logLevel, String message);
}
