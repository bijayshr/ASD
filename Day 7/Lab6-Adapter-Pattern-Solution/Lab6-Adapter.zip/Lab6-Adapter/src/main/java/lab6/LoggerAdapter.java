package lab6;

import org.apache.logging.log4j.LogManager;

public class LoggerAdapter implements Logger {

    private static final org.apache.logging.log4j.Logger log4j = LogManager.getLogger(LoggerAdapter.class);

    @Override
    public void log(LogLevel logLevel, String message) {
        if (logLevel == LogLevel.DEBUG)
            log4j.debug(message);
        else if (logLevel == LogLevel.ERROR)
            log4j.error(message);
        else if (logLevel == LogLevel.FATAL)
            log4j.fatal(message);
        else if (logLevel == LogLevel.INFO)
            log4j.info(message);
        else if (logLevel == LogLevel.TRACE)
            log4j.trace(message);
        else if (logLevel == LogLevel.WARNING)
            log4j.warn(message);
    }
}
