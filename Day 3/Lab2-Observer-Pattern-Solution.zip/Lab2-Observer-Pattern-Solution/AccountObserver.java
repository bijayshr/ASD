public interface AccountObserver {
    void update();
}
