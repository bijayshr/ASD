public interface DisplayAccountChange {
    void display();
}
