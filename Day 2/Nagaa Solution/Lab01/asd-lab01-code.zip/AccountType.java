package edu.mum.cs.cs525.labs.skeleton;

public interface AccountType {

	double balanceInterest(double balance);
	String getAccountTypeName();
}
