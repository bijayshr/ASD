package edu.mum.cs.cs525.labs.skeleton;

public class AccountTypeChecking implements AccountType{
    @Override
    public double balanceInterest(double balance) {
        if(balance < 1000) return balance * 0.015;
        else return balance * 0.025;
    }

    @Override
    public String getAccountTypeName() {
        return "Checking";
    }
}
