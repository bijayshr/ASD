package lab1;

public interface InterestBehaviorStrategy {
    double calculateInterest(Account account);
}
