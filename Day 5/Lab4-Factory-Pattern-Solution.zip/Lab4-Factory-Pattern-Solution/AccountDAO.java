import java.util.Collection;

public interface AccountDAO extends GenericAccountDAO {
}
