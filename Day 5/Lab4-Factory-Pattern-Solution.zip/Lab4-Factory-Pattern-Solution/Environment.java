public interface Environment {

    GenericAccountDAO createDAO(EnvironmentType type);
}
