public interface MockAccountDAO extends GenericAccountDAO{
}
